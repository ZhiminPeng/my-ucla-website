#!/bin/bash

#compile the jemdoc files

jemdoc index paper MENU cv ms164 software pic10a15s

rm *~
